"use strict";
/* eslint-disable @typescript-eslint/camelcase */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
exports.stripeWebhookAndCheckoutCallback = exports.getListOfInvoices = exports.cancelSubscription = exports.createSession = void 0;
var bodyParser = require("body-parser");
var stripe_1 = require("stripe");
var Team_1 = require("./models/Team");
var User_1 = require("./models/User");
var dev = process.env.NODE_ENV !== 'production';
var stripeInstance = new stripe_1["default"](dev ? process.env.STRIPE_TEST_SECRETKEY : process.env.STRIPE_LIVE_SECRETKEY, { apiVersion: '2020-08-27' });
function createSession(_a) {
    var userId = _a.userId, teamId = _a.teamId, teamSlug = _a.teamSlug, customerId = _a.customerId, subscriptionId = _a.subscriptionId, userEmail = _a.userEmail, mode = _a.mode;
    var params = {
        customer_email: customerId ? undefined : userEmail,
        customer: customerId,
        payment_method_types: ['card'],
        mode: mode,
        success_url: process.env.URL_API + "/stripe/checkout-completed/{CHECKOUT_SESSION_ID}",
        cancel_url: process.env.URL_APP + "/team/" + teamSlug + "/billing?redirectMessage=Checkout%20canceled",
        metadata: { userId: userId, teamId: teamId }
    };
    console.log('creating Stripe session');
    if (mode === 'subscription') {
        params.line_items = [
            {
                price: dev ? process.env.STRIPE_TEST_PRICEID : process.env.STRIPE_LIVE_PRICEID,
                quantity: 1
            },
        ];
    }
    else if (mode === 'setup') {
        if (!customerId || !subscriptionId) {
            throw new Error('customerId and subscriptionId required');
        }
        params.setup_intent_data = {
            metadata: { customer_id: customerId, subscription_id: subscriptionId }
        };
    }
    return stripeInstance.checkout.sessions.create(params);
}
exports.createSession = createSession;
function retrieveSession(_a) {
    var sessionId = _a.sessionId;
    return stripeInstance.checkout.sessions.retrieve(sessionId, {
        expand: [
            'setup_intent',
            'setup_intent.payment_method',
            'customer',
            'subscription',
            'subscription.default_payment_method',
        ]
    });
}
function updateCustomer(customerId, params) {
    console.log('updating customer', customerId);
    return stripeInstance.customers.update(customerId, params);
}
function updateSubscription(subscriptionId, params) {
    console.log('updating subscription', subscriptionId);
    return stripeInstance.subscriptions.update(subscriptionId, params);
}
function cancelSubscription(_a) {
    var subscriptionId = _a.subscriptionId;
    console.log('cancel subscription', subscriptionId);
    return stripeInstance.subscriptions.del(subscriptionId);
}
exports.cancelSubscription = cancelSubscription;
function getListOfInvoices(_a) {
    var customerId = _a.customerId;
    console.log('getting list of invoices for customer', customerId);
    return stripeInstance.invoices.list({ customer: customerId, limit: 100 });
}
exports.getListOfInvoices = getListOfInvoices;
function stripeWebhookAndCheckoutCallback(_a) {
    var _this = this;
    var server = _a.server;
    server.post('/api/v1/public/stripe-invoice-payment-failed', bodyParser.raw({ type: 'application/json' }), function (req, res, next) { return __awaiter(_this, void 0, void 0, function () {
        var event, subscription, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    event = stripeInstance.webhooks.constructEvent(req.body, req.headers['stripe-signature'], dev ? process.env.STRIPE_TEST_ENDPOINTSECRET : process.env.STRIPE_LIVE_ENDPOINTSECRET);
                    console.log(event.id + ", " + event.type);
                    if (!(event.type === 'invoice.payment_failed')) return [3 /*break*/, 2];
                    subscription = event.data.object.subscription;
                    console.log(JSON.stringify(subscription));
                    return [4 /*yield*/, Team_1["default"].cancelSubscriptionAfterFailedPayment({
                            subscriptionId: JSON.stringify(subscription)
                        })];
                case 1:
                    _a.sent();
                    _a.label = 2;
                case 2:
                    res.sendStatus(200);
                    return [3 /*break*/, 4];
                case 3:
                    err_1 = _a.sent();
                    console.error("Webhook error: " + err_1.message);
                    next(err_1);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); });
    server.get('/stripe/checkout-completed/:sessionId', function (req, res) { return __awaiter(_this, void 0, void 0, function () {
        var sessionId, session, user, team, si, pm, err_2;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    sessionId = req.params.sessionId;
                    return [4 /*yield*/, retrieveSession({ sessionId: sessionId })];
                case 1:
                    session = _a.sent();
                    if (!session || !session.metadata || !session.metadata.userId || !session.metadata.teamId) {
                        throw new Error('Wrong session.');
                    }
                    return [4 /*yield*/, User_1["default"].findById(session.metadata.userId, '_id stripeCustomer email displayName isSubscriptionActive stripeSubscription').setOptions({ lean: true })];
                case 2:
                    user = _a.sent();
                    return [4 /*yield*/, Team_1["default"].findById(session.metadata.teamId, 'isSubscriptionActive stripeSubscription teamLeaderId slug').setOptions({ lean: true })];
                case 3:
                    team = _a.sent();
                    if (!user) {
                        throw new Error('User not found.');
                    }
                    if (!team) {
                        throw new Error('Team not found.');
                    }
                    if (team.teamLeaderId !== user._id.toString()) {
                        throw new Error('Permission denied');
                    }
                    _a.label = 4;
                case 4:
                    _a.trys.push([4, 16, , 17]);
                    if (!(session.mode === 'setup' && session.setup_intent)) return [3 /*break*/, 10];
                    si = session.setup_intent;
                    pm = si.payment_method;
                    if (!user.stripeCustomer) return [3 /*break*/, 6];
                    return [4 /*yield*/, updateCustomer(user.stripeCustomer.id, {
                            invoice_settings: { default_payment_method: pm.id }
                        })];
                case 5:
                    _a.sent();
                    _a.label = 6;
                case 6:
                    if (!team.stripeSubscription) return [3 /*break*/, 8];
                    return [4 /*yield*/, updateSubscription(team.stripeSubscription.id, { default_payment_method: pm.id })];
                case 7:
                    _a.sent();
                    _a.label = 8;
                case 8: return [4 /*yield*/, User_1["default"].changeStripeCard({ session: session, user: user })];
                case 9:
                    _a.sent();
                    return [3 /*break*/, 15];
                case 10:
                    if (!(session.mode === 'subscription')) return [3 /*break*/, 14];
                    return [4 /*yield*/, User_1["default"].saveStripeCustomerAndCard({ session: session, user: user })];
                case 11:
                    _a.sent();
                    return [4 /*yield*/, Team_1["default"].subscribeTeam({ session: session, team: team })];
                case 12:
                    _a.sent();
                    return [4 /*yield*/, User_1["default"].getListOfInvoicesForCustomer({ userId: user._id })];
                case 13:
                    _a.sent();
                    return [3 /*break*/, 15];
                case 14: throw new Error('Wrong session.');
                case 15:
                    res.redirect(process.env.URL_APP + "/team/" + team.slug + "/billing");
                    return [3 /*break*/, 17];
                case 16:
                    err_2 = _a.sent();
                    console.error(err_2);
                    res.redirect(process.env.URL_APP + "/team/" + team.slug + "/billing?redirectMessage=" + (err_2.message || err_2.toString()));
                    return [3 /*break*/, 17];
                case 17: return [2 /*return*/];
            }
        });
    }); });
}
exports.stripeWebhookAndCheckoutCallback = stripeWebhookAndCheckoutCallback;
//# sourceMappingURL=stripe.js.map