"use strict";
exports.__esModule = true;
var aws = require("aws-sdk");
function sendEmail(options) {
    var ses = new aws.SES({
        apiVersion: 'latest',
        region: process.env.AWS_REGION,
        accessKeyId: process.env.AWS_ACCESSKEYID,
        secretAccessKey: process.env.AWS_SECRETACCESSKEY
    });
    return new Promise(function (resolve, reject) {
        ses.sendEmail({
            Source: options.from,
            Destination: {
                CcAddresses: options.cc,
                ToAddresses: options.to
            },
            Message: {
                Subject: {
                    Data: options.subject
                },
                Body: {
                    Html: {
                        Data: options.body
                    }
                }
            },
            ReplyToAddresses: options.replyTo
        }, function (err, info) {
            if (err) {
                reject(err);
            }
            else {
                resolve(info);
            }
        });
    });
}
exports["default"] = sendEmail;
//# sourceMappingURL=aws-ses.js.map